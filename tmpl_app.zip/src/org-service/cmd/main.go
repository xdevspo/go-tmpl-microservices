package main

import "fmt"

func main() {
	fmt.Println("Hello, world from org-service")
}
